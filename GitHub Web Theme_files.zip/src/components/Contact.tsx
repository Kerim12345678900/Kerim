import  { Mail, Github, Phone } from 'lucide-react';

const Contact = () => {
  return (
    <section id="contact" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-github-text sm:text-4xl">
            Get in Touch
          </h2>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 mx-auto">
            Have questions about Git or GitHub? We're here to help.
          </p>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-8 md:grid-cols-2">
          <div>
            <div className="card">
              <h3 className="text-xl font-medium text-github-text mb-4">Contact Information</h3>
              
              <div className="space-y-4">
                <div className="flex items-center">
                  <Mail className="h-5 w-5 text-github-blue" />
                  <span className="ml-3 text-gray-500">contact@gitportal.example</span>
                </div>
                
                <div className="flex items-center">
                  <Phone className="h-5 w-5 text-github-blue" />
                  <span className="ml-3 text-gray-500">+1 (555) 123-4567</span>
                </div>
                
                <div className="flex items-center">
                  <Github className="h-5 w-5 text-github-blue" />
                  <a href="#" className="ml-3 text-github-blue hover:underline">github.com/gitportal</a>
                </div>
              </div>
              
              <div className="mt-8">
                <img src="https://images.unsplash.com/photo-1615525137689-198778541af6?ixlib=rb-4.0.3&fit=fillmax" alt="Code sample" className="w-full h-56 object-cover rounded-md" />
              </div>
            </div>
          </div>
          
          <div>
            <form className="card">
              <h3 className="text-xl font-medium text-github-text mb-4">Send a Message</h3>
              
              <div className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700">Name</label>
                  <input type="text" id="name" className="mt-1 block w-full border border-github-border rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-github-blue focus:border-github-blue" />
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email</label>
                  <input type="email" id="email" className="mt-1 block w-full border border-github-border rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-github-blue focus:border-github-blue" />
                </div>
                
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700">Message</label>
                  <textarea id="message" rows={4} className="mt-1 block w-full border border-github-border rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-github-blue focus:border-github-blue"></textarea>
                </div>
              </div>
              
              <div className="mt-6">
                <button type="submit" className="w-full btn btn-primary">
                  Send Message
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
 