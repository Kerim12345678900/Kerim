import  { Testimonial } from '../types';

const Testimonials = () => {
  const testimonials: Testimonial[] = [
    {
      id: 1,
      name: "Sarah Johnson",
      role: "Senior Developer",
      content: "Using Git has transformed our development workflow. Code reviews are easier, bugs are tracked efficiently, and collaboration has never been smoother."
    },
    {
      id: 2,
      name: "David Chen",
      role: "Open Source Contributor",
      content: "GitHub has made it possible for me to contribute to projects around the world. The intuitive interface and powerful features make version control accessible to everyone."
    },
    {
      id: 3,
      name: "Maria Rodriguez",
      role: "Tech Lead",
      content: "We manage 50+ repositories across multiple teams with Git. The branching model allows us to work on features in parallel without stepping on each other's toes."
    }
  ];

  return (
    <section id="testimonials" className="py-16 bg-github-dark text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold sm:text-4xl">
            Trusted by Developers Worldwide
          </h2>
          <p className="mt-4 max-w-2xl text-xl text-gray-300 mx-auto">
            See what others are saying about their Git and GitHub experience.
          </p>
        </div>

        <div className="mt-12 grid gap-8 grid-cols-1 md:grid-cols-3">
          {testimonials.map((testimonial) => (
            <div key={testimonial.id} className="bg-gray-800 rounded-lg p-6 shadow-md">
              <div className="text-yellow-400 mb-4">★★★★★</div>
              <p className="text-gray-300 mb-4">{testimonial.content}</p>
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="h-10 w-10 rounded-full bg-github-blue flex items-center justify-center text-white font-bold">
                    {testimonial.name.charAt(0)}
                  </div>
                </div>
                <div className="ml-3">
                  <h3 className="text-white font-medium">{testimonial.name}</h3>
                  <p className="text-gray-400 text-sm">{testimonial.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
 