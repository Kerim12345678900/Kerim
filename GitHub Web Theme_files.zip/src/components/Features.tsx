import  { Code, Github, ArrowRight, Globe, Users, Lock } from 'lucide-react';
import { Feature } from '../types';

const Features = () => {
  const features: Feature[] = [
    {
      id: 1,
      title: "Version Control",
      description: "Track changes, revert to previous stages, and maintain different versions of your code effortlessly.",
      icon: "Code"
    },
    {
      id: 2,
      title: "Collaboration",
      description: "Work together with your team on the same codebase without conflicts or overwriting each other's work.",
      icon: "Users"
    },
    {
      id: 3,
      title: "GitHub Integration",
      description: "Seamless integration with GitHub for pull requests, code reviews, and issue tracking.",
      icon: "Github"
    },
    {
      id: 4,
      title: "Global Access",
      description: "Access your code from anywhere in the world with secure cloud storage for your repositories.",
      icon: "Globe"
    },
    {
      id: 5,
      title: "Security",
      description: "Keep your code secure with advanced permission controls and authentication features.",
      icon: "Lock"
    }
  ];

  const renderIcon = (iconName: string) => {
    switch (iconName) {
      case 'Code': return <Code className="h-6 w-6 text-github-blue" />;
      case 'Users': return <Users className="h-6 w-6 text-github-blue" />;
      case 'Github': return <Github className="h-6 w-6 text-github-blue" />;
      case 'Globe': return <Globe className="h-6 w-6 text-github-blue" />;
      case 'Lock': return <Lock className="h-6 w-6 text-github-blue" />;
      default: return <Code className="h-6 w-6 text-github-blue" />;
    }
  };

  return (
    <section id="features" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-github-text sm:text-4xl">
            Powerful Git Features
          </h2>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 mx-auto">
            Everything you need to manage your code efficiently and collaborate with your team.
          </p>
        </div>

        <div className="mt-12 grid gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
          {features.map((feature) => (
            <div key={feature.id} className="card hover:shadow-md transition-shadow">
              <div className="flex items-center mb-4">
                {renderIcon(feature.icon)}
                <h3 className="ml-3 text-xl font-medium text-github-text">{feature.title}</h3>
              </div>
              <p className="text-gray-500">{feature.description}</p>
              <a href="#" className="mt-4 inline-flex items-center text-github-blue hover:underline">
                Learn more <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
 