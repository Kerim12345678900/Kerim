const  WhyGit = () => {
  return (
    <section id="why-git" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-2 lg:gap-8 lg:items-center">
          <div>
            <h2 className="text-3xl font-extrabold text-github-text sm:text-4xl">
              Why Choose Git?
            </h2>
            <p className="mt-3 max-w-3xl text-lg text-gray-500">
              Git is the most widely used version control system in the world, powering more than 100 million repositories on GitHub.
            </p>
            
            <div className="mt-8 space-y-6">
              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-github-blue text-white">
                    <span className="text-xl font-bold">1</span>
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-github-text">Industry Standard</h3>
                  <p className="mt-2 text-gray-500">Used by 94% of professional developers, Git has become the universal language of code collaboration.</p>
                </div>
              </div>

              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-github-blue text-white">
                    <span className="text-xl font-bold">2</span>
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-github-text">Distributed Workflow</h3>
                  <p className="mt-2 text-gray-500">Work offline with a complete copy of the repository, enabling faster operations and better backup.</p>
                </div>
              </div>

              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-github-blue text-white">
                    <span className="text-xl font-bold">3</span>
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-github-text">Branching and Merging</h3>
                  <p className="mt-2 text-gray-500">Create lightweight branches for features, fixes, and experiments, then merge them back efficiently.</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-10 lg:mt-0">
            <div className="aspect-w-16 aspect-h-9 rounded-lg overflow-hidden shadow-lg">
              <img src="https://images.unsplash.com/photo-1587620962725-abab7fe55159?ixlib=rb-4.0.3&fit=fillmax" alt="Laptop with code" className="w-full h-full object-cover" />
            </div>
            <div className="mt-6">
              <div className="code-block">
                <pre>
                  <code>
{`$ git init
$ git add .
$ git commit -m "Initial commit"
$ git push origin main`}
                  </code>
                </pre>
              </div>
              <p className="mt-2 text-sm text-gray-500">Simple commands to get started with Git</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhyGit;
 