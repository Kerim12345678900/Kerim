/**  @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        github: {
          dark: '#0d1117',
          light: '#f6f8fa',
          blue: '#0969da',
          green: '#2da44e',
          text: '#24292f',
          border: '#d0d7de'
        }
      },
    },
  },
  plugins: [],
};
 